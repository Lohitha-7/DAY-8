import pandas as pd
data=pd.read_csv('students.csv')
print(data.isnull().sum())
data['Marks']=data['Marks'].fillna(0)
data.drop_duplicates(inplace=True)
data['Marks']=data['Marks'].astype(int)
print(data.info())
data.to_csv('cleaned_students.csv',index=False)
print('Done')
