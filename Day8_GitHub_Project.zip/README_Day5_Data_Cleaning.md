# 🧹 Day 5 -- Data Cleaning Using Pandas

## 📌 Project Overview

Data cleaning is one of the most important steps in the data analysis
process. Real-world datasets often contain missing values, duplicate
records, inconsistent formats, and incorrect data types that can affect
the accuracy of analysis. In this project, I used the **Pandas** library
in Python to clean a CSV dataset and prepare it for further analysis.

## 🎯 Objectives

-   Learn the importance of data cleaning.
-   Detect missing values.
-   Handle missing data.
-   Remove duplicate records.
-   Correct data types.
-   Prepare a clean dataset for analysis.

## 🛠 Technologies Used

-   Python
-   Pandas
-   Jupyter Notebook
-   CSV Dataset

## 📋 Tasks Performed

1.  Loaded the dataset using `read_csv()`.
2.  Checked missing values with `isnull()`.
3.  Filled missing values using `fillna()`.
4.  Removed duplicate rows using `drop_duplicates()`.
5.  Corrected data types using `astype()`.
6.  Verified the cleaned dataset using `info()`.

## 💻 Sample Code

``` python
import pandas as pd

data = pd.read_csv("students.csv")
print(data.isnull().sum())
data.fillna(0, inplace=True)
data.drop_duplicates(inplace=True)
data["Marks"] = data["Marks"].astype(int)
print(data.info())
```

## 📈 Expected Outcome

-   Missing values handled
-   Duplicate records removed
-   Correct data types assigned
-   Dataset ready for analysis

## 🎯 Learning Outcomes

-   Improved understanding of data preprocessing.
-   Learned essential Pandas cleaning functions.
-   Prepared high-quality data for analytics.

## 📌 Conclusion

This task demonstrates the importance of data cleaning in producing
reliable and accurate datasets for analysis and visualization.

## 👩‍💻 Author

**Ketha Lohitha**\
**B.Tech -- Data Science**\
**Data Analytics Internship -- Day 5**
